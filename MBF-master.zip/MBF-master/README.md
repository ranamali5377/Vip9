# MBF
$ git clone https://github.com/pangeran151/MBF $ cd MBF $ python2 MBF.py
